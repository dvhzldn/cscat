def lambda_handler(event, context):
    return "Initializing DNS Lambda"
