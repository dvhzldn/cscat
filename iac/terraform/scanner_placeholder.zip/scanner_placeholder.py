def lambda_handler(event, context):
    return "Initializing Scanner Lambda"
